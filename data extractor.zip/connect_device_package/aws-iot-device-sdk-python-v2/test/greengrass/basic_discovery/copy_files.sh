cp ../../../samples/basic_discovery.py .
cp ../../../utils/run_in_ci.py .
cp ../../../.github/workflows/ci_run_greengrass_discovery_cfg.json .
