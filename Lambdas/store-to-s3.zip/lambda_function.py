import json
import boto3
import zipfile
import io
import os

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
sns_client = boto3.client('sns')

# Replace with your S3 bucket name, DynamoDB table name, and SNS topic ARN
BUCKET_NAME = os.getenv('BUCKET_NAME')
TABLE_NAME = os.getenv('TABLE_NAME')
CA_CERT_KEY = 'Root-certificate/root-CA.crt'  # Replace with the actual key for the CA certificate in your S3 bucket

def lambda_handler(event, context):
    for record in event['Records']:
        message = json.loads(record['body'])
        username = message.get('username')
        thing_name = message.get('thingName')
        certificate_pem = message.get('certificatePem')
        private_key = message.get('privateKey')
        public_key = message.get('publicKey')
        email = message.get('email')
        topic_arn = message.get('topic_arn')
        
        if not all([username, thing_name, certificate_pem, private_key, public_key]):
            return {
                'statusCode': 400,
                'body': json.dumps('Missing required information')
            }

        try:
            # Retrieve the existing CA certificate from S3
            ca_cert_obj = s3_client.get_object(Bucket=BUCKET_NAME, Key=CA_CERT_KEY)
            ca_cert = ca_cert_obj['Body'].read().decode('utf-8')
            print("got the certificate")
            # Store new credentials in S3
            s3_client.put_object(
                Bucket=BUCKET_NAME,
                Key=f"{thing_name}/certificate.pem",
                Body=certificate_pem
            )
            s3_client.put_object(
                Bucket=BUCKET_NAME,
                Key=f"{thing_name}/private.key",
                Body=private_key
            )
            s3_client.put_object(
                Bucket=BUCKET_NAME,
                Key=f"{thing_name}/public.key",
                Body=public_key
            )

            # Create a zip file with all the credentials
            zip_buffer = io.BytesIO()
            with zipfile.ZipFile(zip_buffer, 'w') as z:
                z.writestr('certificate.pem', certificate_pem)
                z.writestr('private.key', private_key)
                z.writestr('public.key', public_key)
                z.writestr('root-CA.crt', ca_cert)
            zip_buffer.seek(0)

            # Upload the zip file to S3
            zip_key = f"{thing_name}/connection-kit.zip"
            s3_client.put_object(
                Bucket=BUCKET_NAME,
                Key=zip_key,
                Body=zip_buffer.getvalue()
            )

            # Construct the S3 URLs
            certificate_url = f"https://{BUCKET_NAME}.s3.amazonaws.com/{thing_name}/certificate.pem"
            private_key_url = f"https://{BUCKET_NAME}.s3.amazonaws.com/{thing_name}/private.key"
            public_key_url = f"https://{BUCKET_NAME}.s3.amazonaws.com/{thing_name}/public.key"
            ca_cert_url = f"https://{BUCKET_NAME}.s3.amazonaws.com/{CA_CERT_KEY}"
            zip_url = f"https://{BUCKET_NAME}.s3.amazonaws.com/{zip_key}"
                
            # Store URLs in DynamoDB
            table = dynamodb.Table(TABLE_NAME)
            table.update_item(
                Key={'userID': username},
                UpdateExpression="set certificateUrl = :c, privateKeyUrl = :p, publicKeyUrl = :u, caCertUrl = :a, zipUrl = :z",
                ExpressionAttributeValues={
                    ':c': certificate_url,
                    ':p': private_key_url,
                    ':u': public_key_url,
                    ':a': ca_cert_url,
                    ':z': zip_url
                }
            )
            print("stored to dynamo")

            # Send an email to the user using SNS
            email_subject = "Your IoT Device connection-kit"
            email_body = f"Your IoT device credentials have been generated. You can download them from the following link:\n\n{zip_url}"
            sns_client.publish(
                TopicArn=topic_arn,
                Subject=email_subject,
                Message=email_body,
                MessageAttributes={
                    'email': {
                        'DataType': 'String',
                        'StringValue': email
                    }
                }
            )

        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps(f"Error processing request: {str(e)}")
            }

    return {
        'statusCode': 200,
        'body': json.dumps('Credentials stored and email sent successfully')
    }
