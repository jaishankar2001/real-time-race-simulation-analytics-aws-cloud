import json
import boto3
import os

iot_client = boto3.client('iot')
sqs = boto3.client('sqs')

# Replace with your SQS queue URL
THING_CREATED_QUEUE_URL = os.getenv('THING_CREATED_QUEUE_URL')
ACCOUNT_ID = os.getenv('ACCOUNT_ID')

def lambda_handler(event, context):
    for record in event['Records']:
        print(record)
        message = json.loads(record['body'])
        username = message.get('username')
        email = message.get('email')
        topic_arn = message.get('topic_arn')
        if not username:
            return {
                'statusCode': 400,
                'body': json.dumps('Username is required')
            }

        thing_name = f"{username}-thing"
        policy_name = f"{username}-policy"

        # Create IoT Thing
        try:
            response = iot_client.create_thing(
                thingName=thing_name
            )
            thing_arn = response['thingArn']
            print("thing created successfully")
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps(f"Error creating IoT Thing: {str(e)}")
            }

        # Create IoT Policy
        try:
            policy_document = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": [
                            "iot:Publish",
                            "iot:Receive",
                            "iot:PublishRetain"
                        ],
                        "Resource": [
                            "arn:aws:iot:us-east-1:"+ACCOUNT_ID+":topic/cars/information",
                            "arn:aws:iot:us-east-1:"+ACCOUNT_ID+":topic/data/"+username+"/*",
                        ]
                    },
                    {
                        "Effect": "Allow",
                        "Action": [
                            "iot:Connect",
                        ],
                        "Resource": [
                            "arn:aws:iot:us-east-1:"+ACCOUNT_ID+":client/"+username,
                        ]
                    }
                ]
            }

            response = iot_client.create_policy(
                policyName=policy_name,
                policyDocument=json.dumps(policy_document)
            )
            policy_arn = response['policyArn']
            print("policy created successfully")
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps(f"Error creating IoT Policy: {str(e)}")
            }

        # Generate IoT credentials (thing certificate, key, and CA cert)
        try:
            response = iot_client.create_keys_and_certificate(
                setAsActive=True
            )
            certificate_arn = response['certificateArn']
            certificate_id = response['certificateId']
            certificate_pem = response['certificatePem']
            key_pair = response['keyPair']
            private_key = key_pair['PrivateKey']
            public_key = key_pair['PublicKey']

        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps(f"Error creating IoT Certificate: {str(e)}")
            }
        print("connection kit created successfully")

        # Attach Policy to Certificate
        try:
            response = iot_client.attach_policy(
                policyName=policy_name,
                target=certificate_arn
            )
            print("policy attached successfully")

        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps(f"Error attaching Policy: {str(e)}")
            }
        
        # Send message to the next queue
        sqs.send_message(
            QueueUrl=THING_CREATED_QUEUE_URL,
            MessageBody=json.dumps({
                'username': username,
                'thingName': thing_name,
                'certificatePem': certificate_pem,
                'privateKey': private_key,
                'publicKey': public_key,
                'email': email,
                'topic_arn': topic_arn
            })
        )
        print("sent to new queue successfully")

    return {
        'statusCode': 200,
        'body': json.dumps('Thing created and message sent to the next queue')
    }
