import json
import boto3
import hashlib
import os


dynamodb = boto3.resource('dynamodb')
sqs = boto3.client('sqs')
sns = boto3.client('sns')

# Replace with your DynamoDB table name and SQS queue URL
TABLE_NAME = os.getenv('TABLE_NAME')
USER_EXISTS_QUEUE_URL = os.getenv('USER_EXISTS_QUEUE_URL')

def lambda_handler(event, context):
    body = json.loads(event['body'])
    username = body['username']
    password = body['password']
    hashed_value = hashlib.md5(password.encode()).hexdigest()

    if not username:
        return {
            'statusCode': 400,
            'body': json.dumps('Username is required')
        }

    table = dynamodb.Table(TABLE_NAME)
    response = table.get_item(
        Key={'userID': username}
    )

    if 'Item' not in response:
        return {
            'statusCode': 404,
            'body': json.dumps('User not found')
        }

    user_data = response['Item']
    sns_topic_arn = user_data.get('topic_arn')
    user_email = user_data.get('email')
    user_pass = user_data.get('password')

    if not sns_topic_arn:
        return {
            'statusCode': 404,
            'body': json.dumps('SNS topic ARN not found for the user')
        }

    if not user_email:
        return {
            'statusCode': 404,
            'body': json.dumps('User email not found')
        }
    if user_pass != hashed_value:
        return {
            'statusCode': 404,
            'body': "invalidpassword"
        }
    subscriptions = sns.list_subscriptions_by_topic(TopicArn=sns_topic_arn)
    user_subscriptions = [
        sub for sub in subscriptions['Subscriptions'] if sub['Endpoint'] == user_email
    ]

    if not user_subscriptions:
        return {
            'statusCode': 404,
            'body': json.dumps('User found but no subscriptions to the SNS topic')
        }

    sqs.send_message(
        QueueUrl=USER_EXISTS_QUEUE_URL,
        MessageBody=json.dumps({'username': username, 'email': user_email, 'topic_arn': sns_topic_arn})
    )

    return {
        'statusCode': 200,
        'body': json.dumps('User exists and has subscriptions, message sent to the next queue')
    }
