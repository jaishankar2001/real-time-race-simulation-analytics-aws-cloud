import json
import boto3
import os
import hashlib

sns = boto3.client('sns')
dynamodb = boto3.resource('dynamodb')

# Environment variables for the DynamoDB table name
TABLE_NAME = os.getenv('TABLE_NAME')
def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        user_id = body['user_id']
        email = body['user_email']
        password = body['password']
        hashed_value = hashlib.md5(password.encode()).hexdigest()
        print("password ", hashed_value)
        # Create an SNS topic
        response = sns.create_topic(
            Name=f"{user_id}_topic"
        )
        
        topic_arn = response['TopicArn']
        print(topic_arn)
        # Store the topic ARN in DynamoDB
        table = dynamodb.Table(TABLE_NAME)
        table.put_item(
            Item={
                'userID': user_id,
                'email': email,
                'password': hashed_value,
                'topic_arn': topic_arn
            }
        )
        sns.subscribe(
                TopicArn=topic_arn,
                Protocol='email',
                Endpoint=email
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps('SNS topic created and stored successfully!')
        }
        
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',  # Adjust as needed
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps('An error occurred while creating the SNS topic.')
        }
